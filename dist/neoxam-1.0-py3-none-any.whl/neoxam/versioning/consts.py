# -*- coding: utf-8 -*-

ELASTICSEARCH_LOCK = 'versioning.elasticsearch'
