# -*- coding: utf-8 -*-
check_connectivity_timeout = 2
