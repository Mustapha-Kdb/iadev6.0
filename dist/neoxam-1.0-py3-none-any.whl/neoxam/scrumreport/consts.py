# -*- coding: utf-8 -*-
JIRA_URL = 'https://support.neoxam.com/'
JIRA_REST_URL = JIRA_URL + 'rest/'
