# -*- coding: utf-8 -*-
from django.apps import AppConfig


class GpatcherConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'neoxam.gpatcher'
