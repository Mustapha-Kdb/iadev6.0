import datetime

FILTERING_THRESHOLD = datetime.timedelta(hours=0)
RECORD_LOCK = 'initial.initialcommitrecord'
VERSION = 2009
PAGINATION = 10
STARTING_REVISION = 157000
