# -*- coding: utf-8 -*-
from django.apps import AppConfig


class FactoryAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'neoxam.factory_app'
