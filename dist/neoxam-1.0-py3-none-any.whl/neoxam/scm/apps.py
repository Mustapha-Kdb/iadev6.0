# -*- coding: utf-8 -*-
from django.apps import AppConfig


class ScmConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'neoxam.scm'
