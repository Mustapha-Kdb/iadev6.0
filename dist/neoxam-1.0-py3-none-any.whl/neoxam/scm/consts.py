# -*- coding: utf-8 -*-
SUBVERSION = 'svn'
SCM_CHOICES = (
    (SUBVERSION, 'Subversion'),
)
