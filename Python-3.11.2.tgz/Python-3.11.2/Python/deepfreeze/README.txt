This directory contains the generated .c files for all the deep-frozen
modules.  Python/frozen.c depends on these files.

None of these files are committed into the repo.

See Tools/scripts/freeze_modules.py for more info.
