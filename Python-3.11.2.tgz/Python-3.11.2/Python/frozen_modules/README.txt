This directory contains the generated .h files for all the frozen
modules.  Python/frozen.c depends on these files.

Note that, other than the required frozen modules, none of these files
are committed into the repo.

See Tools/scripts/freeze_modules.py for more info.
